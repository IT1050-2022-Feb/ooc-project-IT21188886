#include <iostream>

int main() {

  class Vehicle{
    private:
      int Vehicle_ID;
      char Vehicle_Name;
      char Vehicle_Number;
      int Vehicle_Price; 

    public:
      Vehicle();
      Vehicle(int V_id, char V_name, char V_number[], int V_price[]);
      int  CaluclateAmount(int price);
      void UpdateDetails();
      void DisplayVehicle();
  };

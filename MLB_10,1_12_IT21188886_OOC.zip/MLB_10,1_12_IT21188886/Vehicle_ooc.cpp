#include <iostream>
#include "Vehicle.h"
#include <cstring>
using namespace std;


Vehicle::Vehicle()  {
  Vehicle_ID-0;
  Vehicle_Price = 0;
    strcpy(Vehicle_Name, "");
    strcpy(Vehicle_Number, "");
    
  }

{
  Vehicle::Vehicle(int V_id, int V_price, char V_name[], char V_number[]) 
  {
      Vehicle_ID=V_id;
      Vehicle_Price = V_price;
      strcpy(Vehicle_Name, V_name);
      strcpy(Vehicle_Number,V_number);
}

      void Vehicle::UpdateDetails(){
        
      }

      void Vehicle::DisplayVehicle(){
        
      }
       void Vehicle::CaluclateAmount(int price){
        
      }

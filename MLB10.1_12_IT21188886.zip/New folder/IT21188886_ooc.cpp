#include <iostream>
#include<payment.h>
#include <cstring>
using namespace std;


payment::payment()  {
  payment_ID-0;
    strcpy(Amount, "");
    strcpy(Ptype, "");
  }

{
  payment::payment(int PID, double amount[], char paytype[]);
    payment_ID=PID;
      strcpy(amount, amount);
      strcpy(payment type, pay type);
}

      void payment::payment details(){
        
      }
      void payment::display payment(){
        
      }

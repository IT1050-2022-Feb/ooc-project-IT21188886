#include <iostream>

int main() {

  class payment{
    private:
      int payment_ID;
      double amount;
      char payment_type;

    public:
      payment();
      payment(int PID, double amount, char Ptype[]);
      void paymentdetails();
      void displypayment();
  };
